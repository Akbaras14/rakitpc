// The application is intentionally served from src/index.html.
// The standalone Three.js simulator lives there, so Angular is not bootstrapped.

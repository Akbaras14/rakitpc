import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { EngineService } from '../../service/engine.service';

type Build = { name: string; level: number; summary: string; parts: string[] };

@Component({
  selector: 'app-canvas', standalone: true, imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './canvas.component.html', styleUrl: './canvas.component.sass',
})
export class CanvasComponent implements OnDestroy {
  @ViewChild('rendererCanvas', { static: true }) rendererCanvas!: ElementRef<HTMLCanvasElement>;

  readonly builds: Build[] = [
    { name: 'Budget PC', level: 1, summary: 'Belajar merakit PC dari komponen inti.', parts: ['NZXT H510', 'ASUS PRIME H510M', 'Intel Core i3', '16 GB RAM', '256 GB NVMe', '500 W PSU'] },
    { name: 'Workstation PC', level: 2, summary: 'Build seimbang untuk kerja kreatif.', parts: ['Fractal Meshify C', 'ARDOR GAMING B550M', 'AMD Ryzen 7', '16 GB RGB RAM', 'RTX 3060 Ti', '600 W PSU'] },
    { name: 'Gaming PC', level: 3, summary: 'Build performa tinggi untuk gaming.', parts: ['DEEPCOOL MATREXX 55', 'ROG Strix B550-F', 'AMD Ryzen 9', '32 GB RGB RAM', 'RTX 3080', '750 W PSU'] },
  ];

  readonly steps = ['Siapkan workspace', 'Pasang motherboard', 'Pasang case fan', 'Pasang processor', 'Pasang memory', 'Pasang storage', 'Pasang CPU fan', 'Pasang graphics card', 'Pasang power supply', 'Selesaikan build'];
  selectedBuild = this.builds[0];
  step = 0;
  isRunning = false;
  isHelpOpen = false;
  isComplete = false;
  status = 'Pilih build untuk memulai simulasi.';

  constructor(private readonly engine: EngineService) {}

  start(): void {
    this.isRunning = true; this.isComplete = false; this.step = 0;
    this.status = 'Workspace siap. Tekan Lanjut untuk mulai memasang komponen.';
    this.engine.createScene(this.rendererCanvas, this.selectedBuild.level);
  }

  nextStep(): void {
    if (!this.isRunning || this.isComplete) return;
    this.step += 1;
    if (this.step < this.steps.length) {
      this.engine.loadNextModel(this.selectedBuild.level, this.step + 4);
      this.status = 'Drag komponen yang muncul ke posisi yang sesuai di dalam case.';
    } else {
      this.isComplete = true;
      this.status = 'Build selesai. Kamu bisa menginspeksi hasil rakitan.';
    }
  }

  inspect(): void {
    if (!this.isRunning) return;
    this.engine.inspectModel(); this.status = 'Mode inspeksi aktif — drag untuk memutar model 3D.';
  }

  reset(): void {
    this.engine.ngOnDestroy(); this.isRunning = false; this.isComplete = false; this.step = 0;
    this.status = 'Pilih build untuk memulai simulasi.';
  }

  ngOnDestroy(): void { this.engine.ngOnDestroy(); }
}
